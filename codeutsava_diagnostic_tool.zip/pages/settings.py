"""Settings page — billet profiles, model configuration, system settings."""
import streamlit as st
import json
from pathlib import Path

from utils.config import (
    THEME, DEFAULT_BILLET_PROFILES, DETECTION_CONFIG, DEFECT_CONFIG,
    OCR_CONFIG, BASE_DIR, MODELS_DIR, get_all_profiles,
)
from storage.database import get_database


def render_settings():
    st.markdown('<div class="page-title">⚙️ Settings</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="page-subtitle">Configure billet profiles, models, and system settings</div>',
        unsafe_allow_html=True,
    )

    tab1, tab2, tab3, tab4 = st.tabs([
        "📏 Billet Profiles",
        "🧠 Model Configuration",
        "🔤 OCR Settings",
        "ℹ️ System Info",
    ])

    # ── Billet Profiles ───────────────────────────────────────────
    with tab1:
        st.markdown("### Active Profiles")
        profiles = get_all_profiles()

        for name, profile in profiles.items():
            with st.expander(f"📐 {name}", expanded=False):
                pc1, pc2 = st.columns(2)
                with pc1:
                    st.write(f"**Description:** {profile.get('description', '—')}")
                    st.write(f"**Cross-section:** {profile.get('cross_section', '—')}")
                    st.write(f"**Defect rule:** {profile.get('defect_rule', '—')}")
                    st.write(f"**Required fields:** {', '.join(profile.get('required_fields', []))}")
                with pc2:
                    nl = profile.get('nominal_length_mm', 0)
                    nw = profile.get('nominal_width_mm', 0)
                    nh = profile.get('nominal_height_mm', 0)
                    st.write(f"**Nominal Length:** {nl} mm ({nl/10.0:.1f} cm)")
                    st.write(f"**Nominal Width:** {nw} mm ({nw/10.0:.1f} cm)")
                    st.write(f"**Nominal Height:** {nh} mm ({nh/10.0:.1f} cm)")
                    st.write(f"**Length Tolerance:** ±{profile.get('length_tolerance_mm', 0)} mm (±{profile.get('length_tolerance_mm', 0)/10.0:.2f} cm)")
                    st.write(f"**Width Tolerance:** ±{profile.get('width_tolerance_mm', 0)} mm (±{profile.get('width_tolerance_mm', 0)/10.0:.2f} cm)")
                    st.write(f"**Height Tolerance:** ±{profile.get('height_tolerance_mm', 0)} mm (±{profile.get('height_tolerance_mm', 0)/10.0:.2f} cm)")

        st.markdown("---")
        st.markdown("### ➕ Create Custom Profile")

        cp1, cp2 = st.columns(2)
        with cp1:
            new_name = st.text_input("Profile Name", placeholder="e.g. Custom Billet 800x160x160")
            new_length = st.number_input("Nominal Length (mm)", 0.0, 5000.0, 750.0, 1.0)
            new_width = st.number_input("Nominal Width (mm)", 0.0, 1000.0, 150.0, 1.0)
            new_height = st.number_input("Nominal Height (mm)", 0.0, 1000.0, 150.0, 1.0)
        with cp2:
            new_ltol = st.number_input("Length Tolerance (mm)", 0.0, 100.0, 7.5, 0.5)
            new_wtol = st.number_input("Width Tolerance (mm)", 0.0, 50.0, 3.0, 0.5)
            new_htol = st.number_input("Height Tolerance (mm)", 0.0, 50.0, 3.0, 0.5)
            new_defect_rule = st.selectbox("Defect Rule", ["FAIL", "REWORK", "REVIEW"])
            new_cross = st.selectbox("Cross-section", ["square", "round", "rectangular"])

        if st.button("💾 Save Profile", type="primary"):
            if new_name:
                config_path = BASE_DIR / "config.yaml"
                try:
                    import yaml
                except ImportError:
                    yaml = None

                if yaml is None:
                    st.error("PyYAML is not installed.")
                    return

                config = {}
                if config_path.exists():
                    with open(config_path, "r") as f:
                        config = yaml.safe_load(f) or {}

                if "billet_profiles" not in config:
                    config["billet_profiles"] = {}

                config["billet_profiles"][new_name] = {
                    "nominal_length_mm": new_length,
                    "nominal_width_mm": new_width,
                    "nominal_height_mm": new_height,
                    "length_tolerance_mm": new_ltol,
                    "width_tolerance_mm": new_wtol,
                    "height_tolerance_mm": new_htol,
                    "cross_section": new_cross,
                    "defect_rule": new_defect_rule,
                    "required_fields": ["billet_id"],
                    "description": f"Custom profile: {new_name}",
                }

                with open(config_path, "w") as f:
                    yaml.dump(config, f, default_flow_style=False)

                st.success(f"✅ Profile '{new_name}' saved to config.yaml")
                st.rerun()
            else:
                st.warning("Please enter a profile name.")

    # ── Model Configuration ───────────────────────────────────────
    with tab2:
        st.markdown("### 🧠 Detection Models")

        st.markdown("#### Billet Detector")
        st.write(f"- **Model path:** `{DETECTION_CONFIG['model_path']}`")
        model_exists = Path(DETECTION_CONFIG["model_path"]).exists()
        st.write(f"- **Status:** {'✅ Loaded' if model_exists else '⚠️ Not found (using fallback)'}")
        st.write(f"- **Device:** `{DETECTION_CONFIG['device']}`")
        st.write(f"- **Confidence threshold:** {DETECTION_CONFIG['confidence_threshold']}")

        st.markdown("#### Defect Detector")
        st.write(f"- **Model path:** `{DEFECT_CONFIG['model_path']}`")
        defect_model_exists = Path(DEFECT_CONFIG["model_path"]).exists()
        st.write(f"- **Status:** {'✅ Loaded' if defect_model_exists else '⚠️ Not found (using heuristic fallback)'}")
        st.write(f"- **Patch size:** {DEFECT_CONFIG['patch_size']}px")
        st.write(f"- **Patch overlap:** {DEFECT_CONFIG['patch_overlap']}")

        st.markdown("---")
        st.markdown("#### Upload Custom Model")
        model_upload = st.file_uploader(
            "Upload a YOLO .pt model file",
            type=["pt"],
            key="model_upload",
        )
        model_target = st.selectbox("Target", ["Billet Detector", "Defect Detector"])

        if model_upload and st.button("📤 Upload Model"):
            if model_target == "Billet Detector":
                target_path = MODELS_DIR / "billet_detector.pt"
            else:
                target_path = MODELS_DIR / "defect_detector.pt"

            with open(target_path, "wb") as f:
                f.write(model_upload.read())

            st.success(f"✅ Model saved to `{target_path}`. Restart the app to load it.")

    # ── OCR Settings ──────────────────────────────────────────────
    with tab3:
        st.markdown("### 🔤 OCR Configuration")
        st.write(f"- **Engine:** `{OCR_CONFIG['engine']}`")
        st.write(f"- **Languages:** {OCR_CONFIG['language']}")
        st.write(f"- **Confidence threshold:** {OCR_CONFIG['confidence_threshold']}")
        st.write(f"- **GPU enabled:** {OCR_CONFIG['gpu_enabled']}")

        st.markdown("#### ID Patterns")
        for name, pattern in OCR_CONFIG["id_patterns"].items():
            st.write(f"- **{name}:** `{pattern}`")

        st.markdown("#### Preprocessing Methods")
        for method in OCR_CONFIG["preprocessing_methods"]:
            st.write(f"- {method}")

    # ── System Info ───────────────────────────────────────────────
    with tab4:
        st.markdown("### ℹ️ System Information")
        import sys
        import platform

        si1, si2 = st.columns(2)
        with si1:
            st.write(f"- **Python:** {sys.version.split()[0]}")
            st.write(f"- **Platform:** {platform.platform()}")
            st.write(f"- **Project dir:** `{BASE_DIR}`")

            # Check dependencies
            deps = {
                "streamlit": "streamlit",
                "opencv": "cv2",
                "numpy": "numpy",
                "pandas": "pandas",
                "plotly": "plotly",
                "torch": "torch",
                "ultralytics": "ultralytics",
                "rapidocr": "rapidocr_onnxruntime",
                "onnxruntime": "onnxruntime",
                "easyocr": "easyocr",
                "openpyxl": "openpyxl",
            }
            st.markdown("#### Dependencies")
            for name, module in deps.items():
                try:
                    mod = __import__(module)
                    ver = getattr(mod, "__version__", "installed")
                    st.write(f"- ✅ {name}: {ver}")
                except Exception:
                    st.write(f"- ❌ {name}: not installed")

        with si2:
            db = get_database()
            stats = db.get_stats()
            st.markdown("#### Database Stats")
            st.write(f"- Total records: {stats['total']}")
            st.write(f"- Database path: `{db.db_path}`")
            st.write(f"- Alerts: {len(db.get_alerts())}")
            st.write(f"- Review flags: {len(db.get_review_flags())}")

            st.markdown("#### Storage")
            from utils.config import DATA_DIR, EVIDENCE_DIR, OUTPUT_DIR
            for label, path in [("Data", DATA_DIR), ("Evidence", EVIDENCE_DIR), ("Output", OUTPUT_DIR)]:
                if path.exists():
                    count = len(list(path.glob("*")))
                    st.write(f"- {label}: {count} file(s)")

        # Database reset
        st.markdown("---")
        st.markdown("### ⚠️ Danger Zone")
        if st.button("🗑️ Clear All Inspection Data", type="secondary"):
            st.warning("This will delete all inspection records, alerts, and review flags.")
            if st.button("⚠️ Confirm Delete", key="confirm_delete"):
                import os
                db.close()
                from utils.config import DATABASE_PATH
                if Path(DATABASE_PATH).exists():
                    os.remove(str(DATABASE_PATH))
                st.success("Database cleared. Restart the app.")
                st.rerun()
